(function ($) {
   "use strict";
    
jQuery(document).ready(function($){
     $(".slide-active").owlCarousel({
          items:1,
            nav:true,
            autoplay:false,
            loop:true,
            dots:false,
            navText:["<i class='fa fa-angle-left'></i>","<i class='fa fa-angle-right'></i>"]
        });
        
    
        $(".recomanded-active").owlCarousel({
          items:1,
            nav:true,
            autoplay:true,
            loop:true,
            dots:false,
            navText:["<i class='fa fa-angle-left'></i>","<i class='fa fa-angle-right'></i>"]
        });
    });
   jQuery(window).load(function(){
       
       
   }); 
    
    
}(jQuery));